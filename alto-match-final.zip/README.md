# Alto Match Final

Versión limpia y funcional del proyecto **Alto Match**.
Desarrollada con **React + Vite + Tailwind CSS**, lista para desplegar en **Vercel**.

## 🚀 Cómo usar
1. Sube estos archivos a tu repositorio `alto-match-final`.
2. Conecta el repositorio a Vercel.
3. Vercel detectará automáticamente la configuración de Vite y desplegará la app.
